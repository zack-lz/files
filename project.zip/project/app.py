from flask import Flask, request, jsonify, render_template, redirect, url_for
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os
import shutil

app = Flask(__name__)

# 配置
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'pdf'}
app.secret_key = 'supersecretkey'

# 数据库初始化
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# 确保目录存在
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# 数据库模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)

class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=True)
    path = db.Column(db.String(300), nullable=False)

# 检查文件是否为允许类型
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# 登录页面
@app.route('/')
def login_page():
    return render_template('login.html')

# 用户注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if User.query.filter_by(username=username).first():
            return "User exists", 400

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login_page'))
    return render_template('register.html')

# 登录验证
@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    user = User.query.filter_by(username=username, password=password).first()
    if user:
        return redirect(url_for('dashboard'))
    return "The user name or password is incorrect", 401

# 主页面 - 上传、分类和预览
@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if request.method == 'POST':
        # 上传文件
        if 'file' not in request.files:
            return "Unselected file", 400   
        file = request.files['file']
        category = request.form.get('category', 'Not classified')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            new_doc = Document(filename=filename, category=category, path=file_path)
            db.session.add(new_doc)
            db.session.commit()

            return redirect(url_for('dashboard'))
    # 显示文档
    documents = Document.query.all()
    return render_template('dashboard.html', documents=documents)

# 删除文件
@app.route('/delete/<int:doc_id>', methods=['POST'])
def delete_file(doc_id):
    doc = Document.query.get_or_404(doc_id)
    if os.path.exists(doc.path):
        os.remove(doc.path)
    db.session.delete(doc)
    db.session.commit()
    return redirect(url_for('dashboard'))

# 文档搜索
@app.route('/search', methods=['GET'])
def search():
    query = request.args.get('query')
    if not query:
        return redirect(url_for('dashboard'))
    results = Document.query.filter(Document.filename.contains(query)).all()
    return render_template('dashboard.html', documents=results)

if __name__ == '__main__':
    app.run(debug=True)
